
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zackads',
  applicationName: 'gromits-poi-service',
  appUid: '3WnRxC216Bv17p9tdv',
  orgUid: '0Tdz7dd9RX0Rc6Z7Cw',
  deploymentUid: 'c836462d-8182-4ae7-97b1-3d33744b9fa6',
  serviceName: 'gromits-poi-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'gromits-poi-service-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}